% ------------------------------------------------------------------------
%   Mackenzie's Secret Santa Code
%   
%   Dear Mackenzie,
%   
% ------------------------------------------------------------------------

close all;

x = randi(40);
A = imread(['Dog',num2str(x),'.jpg']);
figure, imshow(A);

warning('off', 'Images:initSize:adjustingMag');